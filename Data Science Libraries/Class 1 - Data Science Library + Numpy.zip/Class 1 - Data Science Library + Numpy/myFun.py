def myFun1(x):
    return x